//**********************************************************************
//Programmer:	Alexei Abiiaka
//Class:		CS30S
//
//Assignment:	Array Exercise 1
//
//Description:	a brief description of the program goes here
//
//
//	Input:		describe any input from keyboard or file
//
//Output:		describe the result of your program
//***********************************************************************

import javax.swing.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;

public class ArrayOne/*CHANGE THIS TO THE NAME OF THE FILE*/
{  // begin class
	public static void main(String args[])
	{  // begin main
	// ***** declaration of constants *****
		
		Banner banner = new Banner("Array Excercise 1");
		banner.printBanner("Making an array");
		
	// ***** declaration of variables *****
		String str1 ="";
		String str2 ="";
		String strall = "";
        int array_size = 0;
	// ***** create objects *****
		
		
	// ***** create input stream *****
	
		//ConsoleReader console = new ConsoleReader(System.in);
		
	// ***** get input *****
	
		// all input is gathered in this section
		// remember to put ConsoleReader.class into the
		// same folder.
        
        array_size = output("Input number for size of array:  ");
        //array_size--;
        
        
        
	// ***** processing *****
	int[] list = new int[array_size];
	for (int i = 0; i < array_size; i++) {
		list[i]=output("Please enter num: ");
	}
		
		// ***** output order ASC*****
	System.out.println("Original Order");
	for (int i = 0; i < array_size; i++) {
	 // System.out.println(list[i]);
	  str1+=list[i];
	  str1+=",";
	}
	strall="Original Order; \n\r";
	strall+=str1;
	System.out.println(str1);
	
		// ***** output order DESC*****
	System.out.println("Reverse Order");
		for (int i = array_size -1; i > -1; i--) {
		  //System.out.println(list[i]);
		  str2+=list[i];
		  str2+=",";
		}
	strall+="\nReverse Order; \n\r";
	strall+=str2;
	System.out.println(str2);
	
		
		
	// ***** closing message *****
	
		JOptionPane.showMessageDialog(null, strall);
		banner.endOfProcessing();

	}  // end main	
	
		public static int output(String prompt) {// start getNumber
			return new Integer(JOptionPane.showInputDialog(prompt));
		}// end getNumber

		//public static void outputToDialog(String str) {// start outputWindow
		//	JOptionPane.showMessageDialog(null, str);
		//}// end outputWindow


}  // end class













